import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from catboost import CatBoostClassifier

# Обучаемся:
data = pd.read_csv('dataset.csv')
X_train, X_val, y_train, y_val = train_test_split(data.drop(columns=['target']),
                                                  data.target,
                                                  stratify=data.target,
                                                  random_state=42)
clf = CatBoostClassifier(n_estimators=1000,
                         auto_class_weights='Balanced',
                         eval_metric='AUC',
                         learning_rate=0.001,
                         random_seed=42)
clf.fit(X_train,
        y_train,
        eval_set=(X_val, y_val))

# Подбираем порог для округления:
preds = clf.predict_proba(X_val)[:,1]
max_roc = 0
best_thr = None
for threshold in np.linspace(0, 1, num=100):
    preds_rounded = np.array(preds >= threshold)
    roc = roc_auc_score(y_val, preds_rounded)
    if roc > max_roc:
        max_roc = roc
        best_thr = threshold

# Предсказываем:
test = pd.read_csv('test.csv')
test_id = test.id
predictions_proba = clf.predict_proba(test.drop(columns=['id']))[:,1]
predictions = np.array(predictions_proba > best_thr).astype(int)
predictions = pd.DataFrame(np.stack([test_id, predictions]).T, columns=['id', 'target'])
predictions.to_csv('submission.csv', index=False)